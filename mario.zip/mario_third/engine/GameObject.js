import BulletDrawComponent from "./components/BulletDrawComponent.js"
import BulletUpdateComponent from "./components/BulletUpdateComponent.js"
import MapDrawComponent from "./components/MapDrawComponent.js"
import MapUpdateComponent from "./components/MapUpdateComponent.js"
import MarioDrawComponent from "./components/MarioDrawComponent.js"
import MarioUpdateComponent from "./components/MarioUpdateComponent.js"
import TimeUpdateComponent from "./components/TimeUpdateComponent.js"

class GameObject {
    static update() {
        TimeUpdateComponent.update()
        MarioUpdateComponent.update()
        BulletUpdateComponent.update()
        MapUpdateComponent.update()
    }
    static draw() {
        MarioDrawComponent.draw()
        MapDrawComponent.draw()
        BulletDrawComponent.draw()
    }
}

export default GameObject;