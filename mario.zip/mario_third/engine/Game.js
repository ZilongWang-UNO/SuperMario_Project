import Mario from "./components/Mario.js"
import Map from "./components/Map.js"
import Bullet from "./components/Bullet.js"

class Game {
    static start() {
        this.fps = 30;
        this.mario = new Mario()
        this.hp = 3
        this.coin = 0
        this.marioColor = this.mario.color
        this.bullets = []
        this.map = new Map()
        this.tiles = tileList.slice(0)
        this.offsetX = 0
        this.offset = 0
        this.enemyVy = 0
        this.temp = 0
        this.left = false
        this.right = false
        this.down = false
        this.jumping = false
        this.pause = false
        this.paused = false
        this.enemyCount = 0
        this.enemies = []
        this.touchBlock = false
        this.headTouch = false
        this.onGround = false
        this.instruction = true
        this.win = false
        this.gameOver = false
        this.winScene = false
        this.exitFromUnderground = false
        this.sceneColor = '#5C94FC'
        this.sceneType = 1 //1 for main scene, 2 for underground
        this.time = 400
        this.timeCount = 0
    }

    static init() {
        this.mario = new Mario()
        this.marioColor = this.mario.color
        this.bullets = []
        this.map = new Map()
        this.tiles = tileList.slice(0)
        this.offsetX = 0
        this.offset = 0
        this.enemyVy = 0
        this.temp = 0
        this.left = false
        this.right = false
        this.down = false
        this.jumping = false
        this.pause = false
        this.paused = false
        this.enemyCount = 0
        this.enemies = []
        this.touchBlock = false
        this.headTouch = false
        this.onGround = false
        this.win = false
        this.gameOver = false
        this.winScene = false
        this.exitFromUnderground = false
        this.time = 400
        this.timeCount = 0
    }

    static create_bullet() {
        this.bullet = new Bullet()
    }
}

export default Game