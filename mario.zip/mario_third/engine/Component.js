class Component {
  constructor(parent) {
    this.parent = parent;
  }
}

export default Component;