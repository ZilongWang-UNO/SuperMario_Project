function getCanvas() {
    window.canvas = document.querySelector("#canv");
    window.ctx = canvas.getContext("2d");
  
    canvas.width = "640";
    canvas.height = "512";
    return { canvas, ctx };
  }
  
  export {getCanvas};