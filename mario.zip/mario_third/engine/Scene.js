import Component from "./Component.js"
import Game from "./Game.js"

class Scene extends Component {
    constructor(parent) {
        super(parent);
    }

    static draw() {
        ctx.clearRect(0, 0, 1000, 1000);
        ctx.fillStyle = Game.sceneColor
        ctx.fillRect(0, 0, 1000, 1000)
        ctx.fillStyle = "white";
        ctx.font = "20px serif";
        ctx.fillText("SCORE: " + Game.mario.score, 20, 30);
        ctx.fillText("COINS: " + Game.coin, 190, 30);
        ctx.fillText("TIME: " + Game.time, 360, 30);
        ctx.fillText("LIVES: " + Game.hp, 540, 30);

        //instruction
        if (Game.instruction && Game.sceneType == 1) {
            ctx.font = "30px serif";
            ctx.fillText("Super Mario", 20, 100);
            ctx.fillText("By Zilong Wang", 20, 150);
            ctx.fillText("Arrow keys to move", 20, 200);
            ctx.fillText("'Space' to jump", 20, 250);
            ctx.fillText("'X' to shoot bullets", 20, 300);
            ctx.fillText("'P' to pause/continue", 20, 350);
        }

    }

    static drawPause() {
        ctx.clearRect(0, 0, 1000, 1000)
        ctx.fillStyle = '#5C94FC'
        ctx.fillRect(0, 0, 1000, 1000)
        ctx.fillStyle = "white";
        ctx.font = "40px serif";
        ctx.fillText("paused", 250, 200);
        ctx.fillText("Hit 'P' to continue", 180, 300);
    }

    static drawGameOver() {
        ctx.clearRect(0, 0, 1000, 1000)
        ctx.fillStyle = '#5C94FC'
        ctx.fillRect(0, 0, 1000, 1000)
        ctx.fillStyle = "white";
        ctx.font = "40px serif";
        ctx.fillText("Game Over", 210, 250);
        ctx.fillText("Hit 'k' to restart", 180, 310);
    }

    static drawWin() {
        ctx.clearRect(0, 0, 1000, 1000)
        ctx.fillStyle = '#5C94FC'
        ctx.fillRect(0, 0, 1000, 1000)
        ctx.fillStyle = "white";
        ctx.font = "40px serif";
        ctx.fillText("You Win!", 220, 250);
        ctx.fillText("Hit 'k' to restart", 180, 310);
    }

}

export default Scene;