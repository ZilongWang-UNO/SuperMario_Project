import Component from "../Component.js"
import Game from "../Game.js"

class Mario extends Component {
    // this.x = 64;
    // this.y = 416;
    // this.w = 32;
    // this.h = 32;
    // this.speed = 0.4;
    // this.maxSpeed = 7;
    // this.jumpHeight = 96;
    // this.standY = 448;
    // this.vx = 0;
    // this.mx = 0;
    // this.vy = 0;
    // this.gy = 10;
    // this.score = 0;
    // this.color = "yellow";
    // this.colorInv = "red";
    // this.invulnerable = false;
    // this.invulnerableTime = 0;
    // this.endJump = false;
    // this.jumped = false;
    // this.jumping = false;
    // this.faceLeft = false;
    // this.faceRight = true;
    // this.big = false;
    // this.fire = false;

    constructor(parent) {
        super(parent);
        this.x = 64;
        this.y = 416;
        this.w = 32;
        this.h = 32;
        this.speed = 0.4;
        this.maxSpeed = 7;
        this.jumpHeight = 96;
        this.standY = 448;
        this.vx = 0;
        this.mx = 0;
        this.vy = 0;
        this.gy = 10;
        this.score = 0;
        this.color = "yellow";
        this.colorInv = "red";
        this.invulnerable = false;
        this.invulnerableTime = 0;
        this.endJump = false;
        this.jumped = false;
        this.jumping = false;
        this.faceLeft = false;
        this.faceRight = true;
        this.big = false;
        this.fire = false;
    }

    moveLeft() {
        this.vx -= this.speed
        this.mx = this.speed / 2
    }
    moveRight() {
        this.vx += this.speed
        this.mx = -this.speed / 2
    }
    moveJump() {
        this.vy = -10
    }
    changeSize() {
        let map = Game.map
        if (this.h == map.tileSize) {
            this.h += map.tileSize
            this.y -= map.tileSize
            this.big = true
        }
        else {
            this.h = map.tileSize
            this.y += map.tileSize
            this.big = false
        }
    }
}

export default Mario;