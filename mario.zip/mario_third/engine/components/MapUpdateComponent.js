import Component from "../Component.js"
import Game from "../Game.js"

class MapUpdateComponent extends Component {
    constructor(parent) {
        super(parent);
    }
    static update() {
        let map = Game.map
        let i;
        let j;
        if (!Game.win && !Game.exitFromUnderground) {
            //enemies check
            if (Game.enemies.length > 0) {
                for (let key in Game.enemies) {
                    Game.enemies[key].speed -= Game.enemies[key].direction
                    let pos = Game.enemies[key].position
                    let tempSpeed = Game.enemies[key].speed
                    let x = Math.floor(pos / map.th) * map.tileSize + Game.offsetX
                    let y = Game.enemies[key].y
                    i = Math.round((x + tempSpeed) / map.tileSize + Game.offset)
                    j = Math.floor(y / map.tileSize) + 1
                    if (map.onGround(i + 1, j, "enemy")) {
                        i = Math.ceil((x + tempSpeed) / map.tileSize + Game.offset)
                    }
                    else if (map.onGround(i - 1, j, "enemy")) {
                        i = Math.floor((x + tempSpeed) / map.tileSize + Game.offset)
                    }

                    //on ground
                    let onGround = map.onGround(i, j, "enemy")
                    if (!onGround) {
                        Game.enemies[key].y += Game.enemies[key].vy
                        Game.enemies[key].dropSpeed += Game.enemies[key].vy
                        Game.enemies[key].vy += Game.mario.gy * 0.1
                        if (Game.enemies[key].y > 470) {
                            let pos = Game.enemies[key].position
                            Game.tiles[pos] = 0
                            Game.enemies = Game.enemies.filter(a => a.position != pos)
                            break
                        }
                    }
                    else {
                        Game.enemies[key].y = (j - 1) * map.tileSize
                        let y1 = (pos % map.th) * map.tileSize
                        if (Game.enemies[key].dropSpeed != 0)
                            Game.enemies[key].dropSpeed = Game.enemies[key].y - y1
                        Game.enemies[key].vy = 0
                    }

                    //touch block
                    if (Game.enemies[key].direction > 0)
                        i = Math.floor((x + tempSpeed) / map.tileSize + Game.offset)
                    else
                        i = Math.ceil((x + tempSpeed) / map.tileSize + Game.offset)
                    let touchBlock = map.touchBlock(i, j - 1, "enemy")
                    if (touchBlock) {
                        Game.enemies[key].direction *= -1
                    }
                }
            }
        }
    }
}

export default MapUpdateComponent;