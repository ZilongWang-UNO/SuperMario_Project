import Component from "../Component.js"
import Game from "../Game.js"

class TimeUpdateComponent extends Component {
    constructor(parent) {
        super(parent);
    }
    static update() {
        if (!Game.instruction) {
            Game.timeCount++
            if (Game.timeCount == 32) {
                Game.timeCount = 0
                Game.time--
                if (Game.time == 0) {
                    Game.gameOver = true
                }
            }
        }
    }
}

export default TimeUpdateComponent;