import Component from "../Component.js"
import Game from "../Game.js"

class MarioUpdateComponent extends Component {
    constructor(parent) {
        super(parent);
    }
    static update() {
        let i;
        let j;
        let mario = Game.mario
        let map = Game.map
        if (!Game.win && !Game.exitFromUnderground) {
            //head touch check
            Game.offset = Math.abs(Game.offsetX / map.tileSize)
            i = Math.round(mario.x / map.tileSize + Game.offset)
            j = Math.ceil(mario.y / map.tileSize) - 1
            if (map.headTouch(i + 1, j) && map.headTouch(i - 1, j)) {
                i = i
            }
            else if (map.headTouch(i + 1, j)) {
                i = Math.ceil(mario.x / map.tileSize + Game.offset)
            }
            else if (map.headTouch(i - 1, j)) {
                i = Math.floor(mario.x / map.tileSize + Game.offset)
            }

            let headTouch = map.headTouch(i, j)

            if (headTouch) {
                let index = i * map.th + j
                if (Game.tiles[index] == 2) {
                    Game.tiles[index] = 1
                    mario.score += 200

                    //draw mushroom
                    if (items.includes(index))
                        Game.tiles[index - 1] = 6
                    else
                        Game.coin++
                }

                mario.vy *= -1
                mario.jumping = false
                mario.y = (j + 1) * map.tileSize + 1 //move 1 space down in case error occurs
            }

            //touch block check and update mario's x
            if (mario.faceRight) {
                i = Math.floor((mario.x + mario.w) / map.tileSize + Game.offset)
            }
            else if (mario.faceLeft) {
                i = Math.ceil((mario.x - mario.w) / map.tileSize + Game.offset)
            }
            let touchBlock
            j = Math.floor(mario.y / map.tileSize)
            if (mario.h == 64) {
                touchBlock = map.touchBlock(i, j, "mario") || map.touchBlock(i, j + 1, "mario")
            }
            else {
                touchBlock = map.touchBlock(i, j, "mario")
            }

            if (touchBlock) {
                mario.vx = 0
                if (mario.faceRight) {
                    mario.x = (i - 1 - Game.offset) * map.tileSize
                }
                else {
                    mario.x = (i + 1 - Game.offset) * map.tileSize
                }
            }
            else {
                mario.vx += mario.mx
            }

            if (Math.abs(mario.vx) >= mario.maxSpeed) {
                mario.vx = parseInt(mario.vx)
            }

            if (mario.vx * mario.mx > 0) {
                mario.vx = 0
                mario.mx = 0
            }
            else {
                mario.x += mario.vx
            }

            //on ground check
            i = Math.round(mario.x / map.tileSize + Game.offset)
            j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
            if (map.onGround(i + 1, j, "mario")) {
                i = Math.ceil(mario.x / map.tileSize + Game.offset)
            }
            else if (map.onGround(i - 1, j, "mario")) {
                i = Math.floor(mario.x / map.tileSize + Game.offset)
            }

            let onGround = map.onGround(i, j, "mario")

            if (onGround && mario.vy > 0) {
                mario.standY = mario.y + mario.h
                mario.vy = 0
                mario.jumping = false
                mario.endJump = true
            }
            else {
                mario.y += mario.vy
                mario.vy += mario.gy * 0.15
                //drop from map
                if (mario.y >= 480 + mario.h) {
                    Game.hp--
                    if (Game.hp > 0) {
                        Game.init()
                    }
                    else {
                        Game.gameOver = true
                    }
                }
                else {
                    i = Math.round(mario.x / map.tileSize + Game.offset)
                    j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
                    if (map.onGround(i + 1, j, "mario")) {
                        i = Math.ceil(mario.x / map.tileSize + Game.offset)
                    }
                    else if (map.onGround(i - 1, j, "mario")) {
                        i = Math.floor(mario.x / map.tileSize + Game.offset)
                    }
                    onGround = map.onGround(i, j, "mario")
                    if (onGround) {
                        mario.y = (j) * map.tileSize - mario.h
                    }
                    //cannot jump during drop
                    else {
                        mario.endJump = false
                    }
                }
            }

            if (mario.y < mario.standY - mario.jumpHeight - mario.h) {
                mario.jumping = false
                mario.endJump = false
            }

            //invulnerable/invincibility buff   
            if (mario.invulnerable) {
                mario.invulnerableTime++;
                Game.marioColor = mario.colorInv;
                if (mario.invulnerableTime >= Game.fps * 2) {//2 sec invulnerable buff
                    mario.invulnerable = false;
                    Game.marioColor = mario.color;
                    mario.invulnerableTime = 0;
                }
            }

            if (mario.x <= 0) {
                mario.x = 0
            }
            else if (mario.x >= canvas.width / 2) {
                mario.x = canvas.width / 2
                if (Game.right) {
                    Game.offsetX -= Math.floor(mario.vx)
                }
            }

        }

        else if (Game.exitFromUnderground) {
            mario.x += 1
            if (mario.x >= 354) {
                map.changeScene()
                Game.exitFromUnderground = false
            }
        }
        else {
            if (mario.y < 448 - mario.h) {
                mario.y += mario.vy
                mario.vy += mario.gy * 0.15
                i = Math.round(mario.x / map.tileSize + Game.offset)
                j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
                if (map.onGround(i + 1, j, "mario")) {
                    i = Math.ceil(mario.x / map.tileSize + Game.offset)
                }
                else if (map.onGround(i - 1, j, "mario")) {
                    i = Math.floor(mario.x / map.tileSize + Game.offset)
                }
                let onGround = map.onGround(i, j, "mario")
                if (onGround) {
                    mario.y = (j) * map.tileSize - mario.h
                }
            }
            else {
                mario.x += 3
                if (mario.x >= 542)
                    Game.winScene = true
            }
        }
    }

}

export default MarioUpdateComponent;