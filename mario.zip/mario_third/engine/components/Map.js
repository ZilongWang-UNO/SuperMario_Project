import Component from "../Component.js"
import Game from "../Game.js"

class Map extends Component {
    constructor(parent) {
        super(parent);
        this.th = 16;
        this.vx = 0;
        this.mx = 0;
        this.speed = 0.5;
        this.tileSize = 32;
        this.colors = [
            "#C84C0C",   // block       1  // #008088 for scene 2
            "#FC9838",   // items       2
            "#FFFFFF",   // cloud       3
            "#80D010",   // tube        4
            "#fcd8a8",   // enemy       5
            "purple",    // mushroom    6
            "#fc9838",   // coin        7  
        ];
    }

    onGround(i, j, which) {
        let mario = Game.mario
        let map = Game.map
        //
        let p = 0
        let y = 0
        let currentSpeed = 0
        let currentYSpeed = 0
        let index = i * this.th + j
        let tile = Game.tiles[index]
        let index1 = 0

        //go underground
        if ((index == 922 || index == 938) && Game.down && Game.sceneType == 1) {
            this.changeScene()
            return
        }

        //eat coins
        if (tile == 7) {
            mario.score += 200
            Game.coin++
            Game.tiles[index] = 0
        }

        if (Game.enemies.length > 0) {
            for (let key in Game.enemies) {
                currentSpeed = Game.enemies[key].speed
                currentYSpeed = Game.enemies[key].dropSpeed
                y = Game.enemies[key].y
                p = Game.enemies[key].position
                index1 = (i - Math.round(currentSpeed / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)

                if (index1 == p && !mario.jumping && which == "mario") {
                    mario.score += 100
                    Game.tiles[index1] = 0
                    Game.enemies = Game.enemies.filter(a => a.position != index1)
                    break
                }
            }
        }
        return tile == 1 || tile == 2 || tile == 4
    }

    touchBlock(i, j, which) {
        let mario = Game.mario
        let map = Game.map
        let p = 0
        let currentSpeed = 0
        let currentYSpeed = 0
        let index = i * this.th + j
        let tile = Game.tiles[index]
        let hit = false

        //exit from underground
        if (Game.sceneType == 2 && (index == 222 - mario.h / map.tileSize)) {
            Game.exitFromUnderground = true
            return
        }

        //eat mushroom
        if (tile == 6 && which == "mario") {
            if (!mario.big) {
                mario.changeSize()
            }
            else {
                mario.fire = true
            }
            mario.score += 1000
            Game.tiles[index] = 0
        }

        //eat coins
        if (tile == 7 && which == "mario") {
            mario.score += 200
            Game.coin++
            Game.tiles[index] = 0
        }

        if (which == "mario" || which == "bullet") {
            let index1 = 0
            if (Game.enemies.length > 0) {
                for (let key in Game.enemies) {
                    currentSpeed = Game.enemies[key].speed
                    currentYSpeed = Game.enemies[key].dropSpeed
                    p = Game.enemies[key].position
                    if ((mario.faceLeft && Game.enemies[key].direction < 0) || (mario.faceRight && Game.enemies[key].direction > 0))
                        index1 = (i - Math.round(currentSpeed / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)
                    else if (mario.faceRight && Game.enemies[key].direction < 0) {
                        index1 = (i - Math.round((currentSpeed + mario.w) / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)
                    }
                    else
                        index1 = (i - Math.round((currentSpeed - mario.w) / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)

                    //touch enemies, update mario's lives and give buff or reduce body height
                    if (index1 == p) {
                        if (which == "mario") {
                            if (mario.big) {
                                mario.changeSize()
                                mario.fire = false
                                mario.invulnerable = true
                            }
                            else if (!mario.invulnerable) {
                                Game.hp--
                                if (Game.hp > 0) {
                                    Game.init()
                                }
                                else {
                                    Game.gameOver = true
                                }
                            }
                        }
                        else {
                            mario.score += 100
                            hit = true
                            Game.tiles[index1] = 0
                            Game.enemies = Game.enemies.filter(a => a.position != index1)
                        }
                        break
                    }
                }
            }
        }

        //win 
        if (which == "mario" && index >= 3237 && index <= 3245 - mario.h / 32)
            Game.win = true
        return tile == 1 || tile == 2 || tile == 4 || hit
    }

    headTouch(i, j) {
        let mario = Game.mario
        let index = i * this.th + j
        let tile = Game.tiles[index]

        //eat coins
        if (tile == 7) {
            mario.score += 200
            Game.coin++
            Game.tiles[index] = 0
        }

        return tile == 1 || tile == 2
    }

    changeScene() {
        let mario = Game.mario
        if (Game.sceneType == 1) {
            Game.sceneType = 2
            Game.sceneColor = 'black'
            Game.offsetX = 0
            mario.x = 64
            mario.y = 32
            mario.vx = 0
            Game.tiles = tileList2.slice(0)
        }
        else if (Game.sceneType == 2) {
            Game.sceneType = 1
            Game.sceneColor = '#5C94FC'
            Game.offsetX = -5056
            mario.x = 320
            mario.y -= 65
            Game.tiles = tileList.slice(0)
        }
    }
}

export default Map;