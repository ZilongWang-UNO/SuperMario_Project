import Component from "../Component.js"
import Game from "../Game.js"

class BulletDrawComponent extends Component {
    constructor(parent) {
        super(parent);
    }
    static draw() {
        let mario = Game.mario
        for (let i = 0; i < Game.bullets.length; i++) {
            ctx.fillStyle = "orange";
            if (Game.bullets[i].right)
                ctx.fillRect(Game.bullets[i].x + mario.w, Game.bullets[i].y, Game.bullets[i].w, Game.bullets[i].h);
            else
                ctx.fillRect(Game.bullets[i].x, Game.bullets[i].y, Game.bullets[i].w, Game.bullets[i].h);
        }

    }
}

export default BulletDrawComponent;