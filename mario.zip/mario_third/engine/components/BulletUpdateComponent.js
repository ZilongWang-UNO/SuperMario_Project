import Component from "../Component.js"
import Game from "../Game.js"

class BulletUpdateComponent extends Component {
    constructor(parent) {
        super(parent);
    }
    static update() {
        let map = Game.map
        if (!Game.win && !Game.exitFromUnderground) {
            for (let i = 0; i < Game.bullets.length; i++) {
                Game.bullets[i].move()

                //check hit with enemies
                let bi = 0
                if (Game.bullets[i].left)
                    bi = Math.floor((Game.bullets[i].x - Game.bullets[i].w) / map.tileSize + Game.offset)
                else
                    bi = Math.ceil((Game.bullets[i].x + Game.bullets[i].w) / map.tileSize + Game.offset)
                let bj = Math.floor(Game.bullets[i].y / map.tileSize)
                let touchBlock = map.touchBlock(bi, bj, "bullet")
                if (touchBlock) {
                    Game.bullets[i].gone()
                }
                else if (Game.bullets[i].distance >= 350) {
                    Game.bullets[i].gone()
                }
            }
            Game.bullets = Game.bullets.filter(b => b.fire == true)
        }
    }
}

export default BulletUpdateComponent;