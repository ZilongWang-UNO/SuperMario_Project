import Component from "../Component.js"
import Game from "../Game.js"
import Scene from "../Scene.js"

class MapDrawComponent extends Component {
    constructor(parent) {
        super(parent);
    }
    static draw() {
        let map = Game.map
        let offsetIndex = Math.abs(parseInt(Game.offsetX / map.tileSize)) * map.th
        Game.enemies = Game.enemies.filter(a => a.position >= offsetIndex)
        let numberOfTiles = map.th * 21
        let maxIndex = offsetIndex + numberOfTiles
        if (maxIndex > Game.tiles.length) {
            offsetIndex = 0
        }

        //loop through each tile in the tile array and draw accordingly
        for (let i = offsetIndex; i < maxIndex; i++) {
            let index = Game.tiles[i]
            if (index != 0) {
                let x = Math.floor(i / map.th) * map.tileSize + Game.offsetX
                let y = (i % map.th) * map.tileSize
                if (index == 1 && Game.sceneType == 2)
                    ctx.fillStyle = "#008088"
                else
                    ctx.fillStyle = map.colors[index - 1]

                //enemy move
                if (index == 5) {
                    if (!Game.enemies.some(a => a.position == i)) {
                        Game.enemies.push({ "number": Game.enemyCount, "position": i, "speed": 0, "direction": 2, "dropSpeed": 0, "vy": 0, "y": y })
                        Game.enemyCount++
                    }
                    for (let key in Game.enemies) {
                        if (Game.enemies[key].position == i) {
                            x += Game.enemies[key].speed
                            y = Game.enemies[key].y
                        }
                    }
                    if (x <= 0) {
                        //if not draw, delete from map and enemies array
                        Game.tiles[i] = 0
                        Game.enemies = Game.enemies.filter(a => a.position != i)
                    }
                }

                ctx.fillRect(x, y, map.tileSize, map.tileSize)
            }
        }

    }
}

export default MapDrawComponent;