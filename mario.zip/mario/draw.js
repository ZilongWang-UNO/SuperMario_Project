function draw() {
    ctx.clearRect(0, 0, 1000, 1000);
    ctx.fillStyle = sceneColor
    ctx.fillRect(0, 0, 1000, 1000)
    ctx.fillStyle = "white";
    ctx.font = "20px serif";
    ctx.fillText("SCORE: " + mario.score, 20, 30);
    ctx.fillText("COINS: " + coin, 280, 30);
    ctx.fillText("LIVES: " + hp, 540, 30);

    //instruction
    if (instruction && sceneType == 1) {
        ctx.font = "30px serif";
        ctx.fillText("Super Mario Brothers", 20, 100);
        ctx.fillText("By Zilong Wang", 20, 150);
        ctx.fillText("Arrow keys to move", 20, 200);
        ctx.fillText("'Space' to jump", 20, 250);
        ctx.fillText("'X' to shot bullets", 20, 300);
        ctx.fillText("'P' to pause/continue", 20, 350);
    }

    //map
    let offsetIndex = Math.abs(parseInt(offsetX / map.tileSize)) * map.th
    enemies = enemies.filter(a => a.position >= offsetIndex)
    let numberOfTiles = map.th * (21)
    let maxIndex = offsetIndex + numberOfTiles
    if (maxIndex > tiles.length) {
        offsetIndex = 0
    }
    for (let i = offsetIndex; i < maxIndex; i++) {
        let index = tiles[i]
        if (index != 0) {
            let x = Math.floor(i / map.th) * map.tileSize + offsetX
            let y = (i % map.th) * map.tileSize
            if (index == 1 && sceneType == 2)
                ctx.fillStyle = "#008088"
            else
                ctx.fillStyle = map.colors[index - 1]

            //enemy move
            if (index == 5) {
                if (!enemies.some(a => a.position == i)) {
                    enemies.push({ "number": enemyCount, "position": i, "speed": 0, "direction": 2, "dropSpeed": 0, "vy": 0, "y": y })
                    enemyCount++
                }
                for (let key in enemies) {
                    if (enemies[key].position == i) {
                        x += enemies[key].speed
                        y = enemies[key].y
                    }
                }
                if (x > 0) {
                    ctx.fillRect(x, y, map.tileSize, map.tileSize);
                }
                else {
                    //if not draw, delete from map and enemies array
                    tiles[i] = 0
                    enemies = enemies.filter(a => a.position != i)
                }
            }
            else
                ctx.fillRect(x, y, map.tileSize, map.tileSize)
        }
    }

    //mario
    if (!mario.fire && !mario.invulnerable)
        ctx.fillStyle = "pink";
    else
        ctx.fillStyle = marioColor;
    ctx.fillRect(mario.x, mario.y, mario.w, mario.h);

    //bullets
    for (let i = 0; i < bullets.length; i++) {
        ctx.fillStyle = "orange";
        if (bullets[i].right)
            ctx.fillRect(bullets[i].x + mario.w, bullets[i].y, bullets[i].w, bullets[i].h);
        else
            ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].w, bullets[i].h);
    }

}

function drawPause() {
    ctx.clearRect(0, 0, 1000, 1000)
    ctx.fillStyle = '#5C94FC'
    ctx.fillRect(0, 0, 1000, 1000)
    ctx.fillStyle = "white";
    ctx.font = "40px serif";
    ctx.fillText("paused", 250, 200);
    ctx.fillText("Hit 'P' to continue", 180, 300);
}

function drawGameOver() {
    ctx.clearRect(0, 0, 1000, 1000)
    ctx.fillStyle = '#5C94FC'
    ctx.fillRect(0, 0, 1000, 1000)
    ctx.fillStyle = "white";
    ctx.font = "40px serif";
    ctx.fillText("Game Over", 210, 250);
    ctx.fillText("Hit 'k' to restart", 180, 310);
}

function drawWin() {
    ctx.clearRect(0, 0, 1000, 1000)
    ctx.fillStyle = '#5C94FC'
    ctx.fillRect(0, 0, 1000, 1000)
    ctx.fillStyle = "white";
    ctx.font = "40px serif";
    ctx.fillText("You Win!", 220, 250);
    ctx.fillText("Hit 'k' to restart", 180, 310);
}