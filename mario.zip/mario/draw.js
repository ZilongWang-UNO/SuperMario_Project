function draw() {
    ctx.clearRect(0, 0, 1000, 1000);
    ctx.fillStyle = '#5C94FC'
    ctx.fillRect(0, 0, 1000, 1000)
    ctx.fillStyle = "white";
    ctx.font = "20px serif";
    ctx.fillText("SCORE: " + mario.score, 20, 30);
    ctx.fillText("COINS: " + mario.coin, 280, 30);
    ctx.fillText("LIVES: " + mario.hp, 540, 30);

    //instruction
    if (instruction) {
        ctx.font = "30px serif";
        ctx.fillText("Super Mario Brothers", 20, 100);
        ctx.fillText("By Zilong Wang", 20, 150);
        ctx.fillText("Arrow keys to move", 20, 200);
        ctx.fillText("'Space' to jump", 20, 250);
        ctx.fillText("'X' to shot bullets", 20, 300);
        ctx.fillText("'P' to pause/continue", 20, 350);
    }

    //mario
    if (!mario.fire)
        ctx.fillStyle = "pink";
    else
        ctx.fillStyle = "yellow";
    ctx.fillRect(mario.x, mario.y, mario.w, mario.h);
    //bullets
    for (let i = 0; i < bullets.length; i++) {
        ctx.fillStyle = "orange";
        if (bullets[i].right)
            ctx.fillRect(bullets[i].x + mario.w, bullets[i].y, bullets[i].w, bullets[i].h);
        else
            ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].w, bullets[i].h);
    }
    //map
    let offsetIndex = Math.abs(parseInt(offsetX / map.tileSize)) * map.th
    let numberOfTiles = map.th * (21)
    let maxIndex = offsetIndex + numberOfTiles
    if (maxIndex > tiles.length) {
        offsetIndex = 0
    }
    for (let i = offsetIndex; i < maxIndex; i++) {
        /*if (headTouch) {
            let index = i2 * map.th + j2
            //if (tiles[index] == 1)
            //tiles[index] = 0
            if (tiles[index] == 2) {
                //for (let key in coin) {
                    //if (coin[key].index == index) {
                        //if (coin[key].number == 4) {
                            tiles[index] = 1
                            //coin = coin.filter(item => item.index != index)
                        //}
                    //}
                //}
            }
        }*/
        let index = tiles[i]
        if (index != 0) {
            let x = Math.floor(i / map.th) * map.tileSize + offsetX
            let y = (i % map.th) * map.tileSize
            ctx.fillStyle = map.colors[index - 1];
            if (index == 5) {//enemy move
                if (!enemies.some(item => item.position == i)) {
                    enemies.push({ "number": enemyCount, "position": i, "speed": 0, "direction": 1, "dropSpeed": 0, "vy": 0, "y": y })
                    enemyCount++
                }
                for (let key in enemies) {
                    if (enemies[key].position == i) {
                        x += enemies[key].speed
                        y = enemies[key].y
                    }
                }
                if (x >= 0) {
                    ctx.fillRect(x, y, map.tileSize, map.tileSize);
                }
                else {
                    //if not draw, delete from map and enemies array
                    tiles[i] = 0
                    enemies = enemies.filter(a => a.position != i)
                }
            }
            else
                ctx.fillRect(x, y, map.tileSize, map.tileSize);
        }
    }
}

function drawPause(){
    ctx.clearRect(0, 0, 1000, 1000)
    ctx.fillStyle = '#5C94FC'
    ctx.fillRect(0, 0, 1000, 1000)
    ctx.fillStyle = "white";
    ctx.font = "40px serif";
    ctx.fillText("paused", 250, 200);
    ctx.fillText("Hit 'P' to continue", 180, 300);
}