function draw() {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    //background
    ctx.fillStyle = "black";
    ctx.fillRect(background.x, background.y, background.w, background.h);
    //ground
    ctx.fillStyle = "green";
    ctx.fillRect(background.x, background.y + 700, background.w, background.h);
    //text
    ctx.fillStyle = "white";
    ctx.font = "20px serif";
    ctx.fillText("Score: " + mario.score, 20, 30);
    ctx.fillText("HP: " + mario.hp, 600, 30);
    //mario
    ctx.fillStyle = marioColor;
    ctx.fillRect(mario.x, mario.y, mario.w, mario.h);
    //monsters
    for (let i = 0; i < monsters.length; i++) {
        if (!monsters[i].kill) {
            ctx.fillStyle = "purple";
            ctx.fillRect(monsters[i].x, monsters[i].y, monsters[i].w, monsters[i].h);
        }
    }
    //bullets
    for (let i = 0; i < bullets.length; i++) {
        if (bullets[i].fire) {
            ctx.fillStyle = "red";
            if (bullets[i].right)
                ctx.fillRect(bullets[i].x + mario.w, bullets[i].y, bullets[i].w, bullets[i].h);
            else
                ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].w, bullets[i].h);
        }
    }
    //blocks
    ctx.fillStyle = "orange";
    ctx.fillRect(block.x, block.y, block.w, block.h);
};