function draw() {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.fillStyle = "green";
    ctx.fillRect(100, 700, 800, 100);
    ctx.fillStyle = "white";
    ctx.font = "20px Georgia";
    ctx.fillText("Score: " + mario.score, 20, 30);
    ctx.fillText("HP: " + mario.hp, 600, 30);
    ctx.fillStyle = marioColor;
    ctx.fillRect(mario.x, mario.y, mario.w, mario.h);
    for (let i = 0; i < monsters.length; i++) {
        if (!monsters[i].kill) {
            ctx.fillStyle = "purple";
            ctx.fillRect(monsters[i].x, monsters[i].y, monsters[i].w, monsters[i].h);
        }
    }
};