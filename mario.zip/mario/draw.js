function draw() {
    ctx.clearRect(0, 0, 1000, 1000);
    ctx.fillStyle = '#5C94FC'
    ctx.fillRect(0, 0, 1000, 1000)

    ctx.fillStyle = "white";
    ctx.font = "20px serif";
    ctx.fillText("SCORE: " + mario.score, 20, 30);
    ctx.fillText("COINS: " + mario.coin, 250, 30);
    ctx.fillText("LIVES: " + mario.hp, 500, 30);
    //mario
    ctx.fillStyle = "pink";
    ctx.fillRect(mario.x, mario.y, mario.w, mario.h);
    //monsters
    /*for (let i = 0; i < monsters.length; i++) {
        //if (!monsters[i].kill) {
            ctx.fillStyle = "purple";
            ctx.fillRect(monsters[i].x, monsters[i].y, monsters[i].w, monsters[i].h);
        //}
    }*/
    
    //bullets
    for (let i = 0; i < bullets.length; i++) {
        ctx.fillStyle = "red";
        if (bullets[i].right)
            ctx.fillRect(bullets[i].x + mario.w, bullets[i].y, bullets[i].w, bullets[i].h);
        else
            ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].w, bullets[i].h);
    }

    //map
    let offsetIndex = Math.abs(parseInt(offsetX / map.tileSize)) * map.th
    let numberOfTiles = map.th * (21)
    let maxIndex = offsetIndex + numberOfTiles
    if (maxIndex > tiles.length) {
        offsetIndex = 0
    }
    //console.log(offsetIndex, numberOfTiles, maxIndex)
    for (let i = offsetIndex; i < maxIndex; i++) {
        /*if (headTouch) {
            let index = i2 * map.th + j2
            //if (tiles[index] == 1)
            //tiles[index] = 0
            if (tiles[index] == 2) {
                //for (let key in coin) {
                    //if (coin[key].index == index) {
                        //if (coin[key].number == 4) {
                            tiles[index] = 1
                            //coin = coin.filter(item => item.index != index)
                        //}
                    //}
                //}
            }
        }*/
        let a123 = 0
        let index = tiles[i]
        if (index != 0) {
            let x = Math.floor(i / map.th) * map.tileSize
            x += offsetX
            let y = (i % map.th) * map.tileSize
            ctx.fillStyle = map.colors[index - 1];
            if (index == 5) {//enemy move
                //console.log(i)
                if (!enemies.some(item => item.position == i)) {
                    enemies.push({ "number": enemyCount, "position": i, "speed": 0, })
                    enemyCount++
                }
                for (let key in enemies) {
                    if (enemies[key].position == i) {
                        a123 = enemies[key].speed
                        x += enemies[key].speed
                        //console.log(enemies[key].speed)
                    }
                }
                /////////////////
                //////////////////
                ////////////////FIXME
                //FIXME
                ////////////////////////////////////////////
                //check on ground of enemy
                //a is not correct
                let a = Math.floor((x)/ map.tileSize * map.th) + y/map.tileSize
                console.log(a)
                if (tiles[a] == 0) {
                    y += enemyVy
                    enemyVy += mario.gy * 0.15
                    if(tiles[a] == 1){
                        //y = 10
                    }
                }
                ctx.fillRect(x, y, map.tileSize, map.tileSize);
            }
            else
                ctx.fillRect(x, y, map.tileSize, map.tileSize);
        }
    }
}