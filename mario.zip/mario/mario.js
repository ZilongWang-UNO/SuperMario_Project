function Mario() {
    let o = {
        x: 64,
        y: 416,
        w: 32,
        h: 32,
        speed: 0.4,
        maxSpeed: 7,
        //jspeed: 20,
        jumpHeight: 96,
        standY: 448,
        vx: 0,
        mx: 0,
        vy: 0,
        gy: 10,
        //topY: 300,
        //standY: 600,
        score: 0,
        color: "yellow",
        colorInv: "red",
        invulnerable: false,
        invulnerableTime: 0,
        //jump: false,
        endJump: false,
        jumped: false,
        jumping: false,
        faceLeft: false,
        faceRight: true,
        big: false,
        fire: false,
    };

    o.moveLeft = function () {
        o.vx -= o.speed
        o.mx = o.speed / 2
    }
    o.moveRight = function () {
        o.vx += o.speed
        o.mx = -o.speed / 2
    }
    o.moveJump = function () {
        o.vy = -10
    }
    o.changeSize = function () {
        if (o.h == 32) {
            o.h = 64
            o.y -= 32
            o.big = true
        }
        else {
            o.h = 32
            o.y += 32
            o.big = false
        }
    }
    return o;
};