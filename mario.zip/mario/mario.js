function Mario() {
    let o = {
        x: 100,
        y: 600,
        w: 50,
        h: 100,
        speed: 10,
        jspeed: 20,
        jumpHeight: 300,
        topY: 300,
        standY: 600,
        hp: 3,
        score: 0,
        color: "yellow",
        colorInv: "red",
        invulnerable: false,
        invulnerableTime: 0,
        jump: false,
        jumped: false, // reach jump height and ready to jump down
        jumping: false,
        faceLeft: false,
        faceRight: true,
        onBlock: false,
        drop: false,
        sideHit: false,
    };
    o.j = o.jspeed;
    o.moveLeft = function () {
        o.x -= o.speed;
    }
    o.moveRight = function () {
        o.x += o.speed;
    }
    o.moveJump = function () {
        o.y -= o.jspeed;
    }
    o.moveDown = function () {
        o.y += o.jspeed;
    }
    o.collideWithMonster = function (m) {
        if (!m.kill) {
            //face to face without jumping
            if ((o.y + o.h == m.y + m.h) && !o.invulnerable) {
                if ((o.x + o.w >= m.x && o.x + o.w <= m.x + m.w) || (o.x >= m.x && o.x <= m.x + m.w)) {
                    o.hp--;
                    o.invulnerable = true;
                    return false;
                }
            }
            //jump onto it
            else if ((o.y + o.h - o.jspeed <= m.y) && (o.y + o.h >= m.y)) {
                if ((o.x + o.w >= m.x && o.x + o.w <= m.x + m.w) || (o.x >= m.x && o.x <= m.x + m.w)) {
                    o.score++;
                    return true;
                }
            }
            return false;
        }
    }
    o.collideWithBlock = function (b) {
        if (o.y + o.h == b.y) {//!!!!!!!!!!!!
            if ((o.x + o.w >= b.x && o.x + o.w <= b.x + b.w) || (o.x >= b.x && o.x <= b.x + b.w)) {
                o.onBlock = true;
                return true;
            }
            else {
                o.onBlock = false;
                return false;
            }
        }
    }
    o.headHitBlock = function (b) {
        if (o.y <= b.y + b.h) {//fix to exact touch 
            if ((o.x + o.w >= b.x && o.x + o.w <= b.x + b.w) || (o.x >= b.x && o.x <= b.x + b.w)) {
                return true;
            }
        }
        else {
            return false
        }
    }
    o.sideHitBlock = function (b) {
        if (o.x + o.w == b.x || o.x == b.x + b.w) {
            if ((b.y >= o.y && b.y <= o.y + o.h) || (b.y + b.h >= o.y && b.y + b.h <= o.y + o.h)) {
                sideHit = true
                return true
            }
            else {
                this.sideHit = false
                return false
            }
        }
    }
    o.dropFromBlock = function (b) {
        if ((o.x + o.w < b.x) || (o.x > b.x + b.w)) {
            o.drop = true;
            return true;
        }
        else {
            o.drop = false;
            return false;
        }
    }
    return o;
};