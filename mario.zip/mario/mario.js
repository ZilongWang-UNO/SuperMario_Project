function Mario() {
    let o = {
        x: 500,
        y: 600,
        w: 50,
        h: 100,
        speed: 10,
        jspeed: 15,
        hp: 3,
        score: 0,
        color: "yellow",
        colorInv: "red",
        invulnerable: false,
        invulnerableTime: 0,
        jump: false,
        jumped: false,
        jumping: false,
    };
    o.j = o.jspeed;
    o.moveLeft = function () {
        o.x -= o.speed;
    }
    o.moveRight = function () {
        o.x += o.speed;
    }
    o.moveJump = function () {
        o.y -= o.jspeed;
    }
    o.collide = function (m) {
        if (!m.kill) {
            //face to face without jumping
            if ((o.y + o.h == m.y + m.h) && !o.invulnerable) {
                if ((o.x + o.w >= m.x && o.x + o.w <= m.x + m.w) || (o.x >= m.x && o.x <= m.x + m.w)) {
                    o.hp--;
                    o.invulnerable = true;
                    return false;
                }
            }
            //jump onto it
            else if ((o.y + o.h + o.jspeed <= m.y) && (o.y + o.h >= m.y)) {
                if ((o.x + o.w >= m.x && o.x + o.w <= m.x + m.w) || (o.x >= m.x && o.x <= m.x + m.w)) {
                    o.score++;
                    return true;
                }
            }
            return false;
        }
    }
    return o;
};