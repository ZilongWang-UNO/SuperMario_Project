
class MapGameObject extends GameObject{
  constructor(){
    super();
    this.components.push(new MapDraw());
    this.components.push(new MapUpdate());
  }

  update(){
    this.components.filter(c=>c.update).forEach(c=>c.update());
  }
  draw(){
    this.components.filter(c=>c.draw).forEach(c=>c.draw(ctx));
  }
}

//export default MapGameObject;