function update() {
    //head touch check
    offset = Math.abs(offsetX / map.tileSize)
    i = Math.round(mario.x / map.tileSize + offset)
    j = Math.ceil(mario.y / map.tileSize) - 1
    if (map.headTouch(i + 1, j) && map.headTouch(i - 1, j)) {
        i = i
    }
    else if (map.headTouch(i + 1, j)) {
        i = Math.ceil(mario.x / map.tileSize + offset)
    }
    else if (map.headTouch(i - 1, j)) {
        i = Math.floor(mario.x / map.tileSize + offset)
    }

    headTouch = map.headTouch(i, j)

    if (headTouch) {
        let index = i * map.th + j
        if (tiles[index] == 2) {
            tiles[index] = 1
            mario.score += 200
            //draw mushroom
            if (items.includes(index))
                tiles[index - 1] = 6
            else
                mario.coin++
        }
        /*
        if (coin.some(item => item.index == index)) {
            for (let key in coin) {
                if (coin[key].index == index) {
                    coin[key].number++
                }
            }
        }
        else {
            coin.push({ "index": index, "number": 1 })
        }
    }*/
        mario.vy *= -1
        mario.jumping = false
        mario.y = (j + 1) * map.tileSize + 1 //move 1 space down in case error occurs
    }

    //touch block check and update mario's x
    if (mario.faceRight) {
        i = Math.floor((mario.x + mario.w) / map.tileSize + offset)
    }
    else if (mario.faceLeft) {
        i = Math.ceil((mario.x - mario.w) / map.tileSize + offset)
    }

    j = Math.floor(mario.y / map.tileSize)
    if (mario.h == 64) {
        touchBlock = map.touchBlock(i, j, "mario") || map.touchBlock(i, j + 1, "mario")
    }
    else {
        touchBlock = map.touchBlock(i, j, "mario")
    }

    if (touchBlock) {
        mario.vx = 0
        if (mario.faceRight) {
            mario.x = (i - 1 - offset) * map.tileSize
        }
        else {
            mario.x = (i + 1 - offset) * map.tileSize
        }
    }
    else {
        mario.vx += mario.mx
    }

    if (Math.abs(mario.vx) >= mario.maxSpeed) {
        mario.vx = parseInt(mario.vx)
    }

    if (mario.vx * mario.mx > 0) {
        mario.vx = 0
        mario.mx = 0
    }
    else {
        mario.x += mario.vx
    }

    //on ground check
    i = Math.round(mario.x / map.tileSize + offset)
    j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
    if (map.onGround(i + 1, j)) {
        i = Math.ceil(mario.x / map.tileSize + offset)
    }
    else if (map.onGround(i - 1, j)) {
        i = Math.floor(mario.x / map.tileSize + offset)
    }

    onGround = map.onGround(i, j)

    if (onGround && mario.vy > 0) {
        mario.standY = mario.y + mario.h
        mario.vy = 0
        mario.jumping = false
        mario.endJump = true
    }
    else {
        mario.y += mario.vy
        mario.vy += mario.gy * 0.15
        i = Math.round(mario.x / map.tileSize + offset)
        j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
        if (map.onGround(i + 1, j)) {
            i = Math.ceil(mario.x / map.tileSize + offset)
        }
        else if (map.onGround(i - 1, j)) {
            i = Math.floor(mario.x / map.tileSize + offset)
        }
        onGround = map.onGround(i, j)
        if (onGround) {
            mario.y = (j) * map.tileSize - mario.h
        }
        //cannot jump during drop
        else {
            mario.endJump = false
        }

    }
    if (mario.y < mario.standY - mario.jumpHeight - mario.h) {
        mario.jumping = false
        mario.endJump = false
    }

    //update each bullet movement

    for (let i = 0; i < bullets.length; i++) {
        bullets[i].move()
        //check hit with enemies
        let bi = 0
        if (bullets[i].left)
            bi = Math.round((bullets[i].x - bullets[i].w) / map.tileSize - 1 + offset)
        else
            bi = Math.round((bullets[i].x + bullets[i].w) / map.tileSize + offset)
        let bj = Math.floor(bullets[i].y / map.tileSize)
        touchBlock = map.touchBlock(bi, bj, "bullet")
        if (touchBlock) {
            mario.score += 100
            bullets[i].gone()
        }
        else if (bullets[i].distance >= 350) {
            bullets[i].gone()
        }
    }
    bullets = bullets.filter(b => b.fire == true)

    //invulnerable buff
    /*if (mario.invulnerable) {
        mario.invulnerableTime++;
        marioColor = mario.colorInv;
        if (mario.invulnerableTime >= fps * 1) {//1 sec invulnerable buff
            mario.invulnerable = false;
            marioColor = mario.color;
            mario.invulnerableTime = 0;
        }
    }
*/
    if (mario.x <= 0) {
        mario.x = 0
    }
    else if (mario.x >= canvas.width / 2) {
        mario.x = canvas.width / 2
        if (right) {
            offsetX -= Math.floor(mario.vx)
        }
    }

    //enemy check

    if (enemies.length > 0) {
        for (let key in enemies) {
            enemies[key].speed -= enemies[key].direction
            let pos = enemies[key].position
            let tempSpeed = enemies[key].speed
            let x = Math.floor(pos / map.th) * map.tileSize + offsetX
            let y = enemies[key].y
            i = Math.round((x + tempSpeed) / map.tileSize + offset)
            j = Math.floor(y / map.tileSize) + 1
            if (map.onGround(i + 1, j)) {
                i = Math.ceil((x + tempSpeed) / map.tileSize + offset)
            }
            else if (map.onGround(i - 1, j)) {
                i = Math.floor((x + tempSpeed) / map.tileSize + offset)
            }

            //on ground

            onGround = map.onGround(i, j)
            if (!onGround) {
                enemies[key].y += enemies[key].vy
                enemies[key].dropSpeed += enemies[key].vy
                enemies[key].vy += mario.gy * 0.1
            }
            else {
                enemies[key].y = j * map.tileSize - 32
                let y1 = (pos % map.th) * map.tileSize
                if(enemies[key].dropSpeed != 0)
                    enemies[key].dropSpeed = enemies[key].y - y1
                enemies[key].vy = 0
            }
            console.log(enemies[key].position, enemies[key].dropSpeed, enemies[key].y)
            //touch block
            if (enemies[key].direction > 0)
                i = Math.floor((x + tempSpeed) / map.tileSize + offset)
            else
                i = Math.ceil((x + tempSpeed) / map.tileSize + offset)
            touchBlock = map.touchBlock(i, j - 1, "enemy")
            if (touchBlock) {
                enemies[key].direction *= -1
            }
        }
        for (let key in enemies) {
            if (enemies[key].y > 470) {
                let pos = enemies[key].position
                tiles[pos] = 0
                //change position to -1
                //to mark that the value needs to be removed from enemies first
                //and then after the for loop finished,
                //remove it by the filter statement below
                //otherwise, if remove immedially
                //will cause error because array size is reduced that
                //the next for loop will read undefined 
                enemies[key].position = -1
                //enemies = enemies.filter(a => a.position != pos)
            }
        }
        enemies = enemies.filter(a => a.position != -1)
    }
};