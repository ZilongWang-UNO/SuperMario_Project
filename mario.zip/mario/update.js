function update() {



    //touch block check and update mario's x
    let offset = Math.abs(offsetX / 32)

    let i = 0
    let j = 0

    i = Math.round(mario.x / map.tileSize + offset)
    j = Math.ceil(mario.y / map.tileSize) - 1
    if (map.headTouch(i + 1, j)) {
        i = Math.ceil(mario.x / map.tileSize + offset)
    }
    else if (map.headTouch(i - 1, j)) {
        i = Math.floor(mario.x / map.tileSize + offset)
    }
    headTouch = map.headTouch(i, j)


    if (headTouch) {
        i2 = i
        j2 = j
        let index = i * map.th + j
        if (tiles[index] == 2) {
            tiles[index] = 1
            mario.score += 200
            mario.coin++
            //console.log(index)
        }
        /*
        if (coin.some(item => item.index == index)) {
            for (let key in coin) {
                if (coin[key].index == index) {
                    coin[key].number++
                }
            }
        }
        else {
            coin.push({ "index": index, "number": 1 })
        }
    }*/
        mario.vy *= -1
        mario.jumping = false
        mario.y = (j + 1) * map.tileSize + 1 //move 1 space down in case error occurs
    }




    if (mario.faceRight) {
        i = Math.floor((mario.x + mario.w - offsetX) / map.tileSize)
    }
    else if (mario.faceLeft) {
        i = Math.ceil((mario.x - mario.w - offsetX) / map.tileSize)
    }

    j = Math.floor(mario.y / map.tileSize)
    if (mario.h == 64) {
        touchBlock = map.touchBlock(i, j) || map.touchBlock(i, j + 1)
    }
    else {
        touchBlock = map.touchBlock(i, j)
    }


    if (touchBlock) {
        mario.vx = 0
        if (mario.faceRight) {
            mario.x = (i - 1 - offset) * map.tileSize
        }
        else {
            mario.x = (i + 1 - offset) * map.tileSize
        }
    }
    else {
        mario.vx += mario.mx
    }

    if (Math.abs(mario.vx) >= mario.maxSpeed) {
        mario.vx = parseInt(mario.vx)
    }

    if (mario.vx * mario.mx > 0) {
        mario.vx = 0
        mario.mx = 0
    }
    else {
        mario.x += mario.vx
    }

    i = Math.round(mario.x / map.tileSize + offset)
    j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
    if (map.onGround(i + 1, j)) {
        i = Math.ceil(mario.x / map.tileSize + offset)
    }
    else if (map.onGround(i - 1, j)) {
        i = Math.floor(mario.x / map.tileSize + offset)
    }

    onGround = map.onGround(i, j)

    if (onGround && mario.vy > 0) {
        mario.standY = mario.y + mario.h
        mario.vy = 0
        mario.jumping = false
        mario.endJump = true
    }
    else {
        mario.y += mario.vy
        mario.vy += mario.gy * 0.15
        let i = Math.round(mario.x / map.tileSize + offset)
        let j = Math.floor(mario.y / map.tileSize) + (mario.h / map.tileSize)
        if (map.onGround(i + 1, j)) {
            i = Math.ceil(mario.x / map.tileSize + offset)
        }
        else if (map.onGround(i - 1, j)) {
            i = Math.floor(mario.x / map.tileSize + offset)
        }
        onGround = map.onGround(i, j)
        if (onGround) {
            mario.y = (j) * map.tileSize - mario.h
        }
        //cannot jump during drop
        else {
            mario.endJump = false
        }

    }
    if (mario.y < mario.standY - mario.jumpHeight - mario.h) {
        mario.jumping = false
        mario.endJump = false
    }

    //update each bullet movement
    for (let i = 0; i < bullets.length; i++) {
        if (bullets[i].fire) {
            bullets[i].move()
            if (bullets[i].distance >= 350) {
                bullets[i].gone()
            }
        }
    }
    bullets = bullets.filter(b => b.fire == true)
    //check for collide with monsters
    /*for (let i = 0; i < monsters.length; i++) {
        if (!monsters[i].kill) {//save memory maybe
            monsters[i].move()
            if (mario.collideWithMonster(monsters[i])) {
                monsters[i].killed()
            }
            for (let j = 0; j < bullets.length; j++) {
                if (bullets[j].fire && bullets[j].collide(monsters[i])) {
                    monsters[i].killed()
                    bullets[j].gone()
                }
            }
        }
    }*/
    //monsters = monsters.filter(m => m.kill == false)
    //bullets = bullets.filter(b => b.fire == true)
    //invulnerable buff
    /*if (mario.invulnerable) {
        mario.invulnerableTime++;
        marioColor = mario.colorInv;
        if (mario.invulnerableTime >= fps * 1) {//1 sec invulnerable buff
            mario.invulnerable = false;
            marioColor = mario.color;
            mario.invulnerableTime = 0;
        }
    }
*/

    if (mario.x <= 0) {
        mario.x = 0
    }
    else if (mario.x >= canvas.width / 2) {
        mario.x = canvas.width / 2
        if (right) {
            offsetX -= Math.floor(mario.vx)
        }
    }

    for (let key in enemies) {
        enemies[key].speed -= 1
    }
    count = 0
    //console.log(touchBlock, headTouch, onGround)
    //console.log(onGround, headTouch)
};