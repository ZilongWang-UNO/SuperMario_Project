function update() {
    //check for collide with block 
    if (!mario.onBlock)
        mario.collideWithBlock(block)
    else if (mario.onBlock) {
        if (mario.dropFromBlock(block)) {
            mario.onBlock = false;
        }
        else
            mario.topY = block.y - mario.jumpHeight - mario.h//!!!!!!!!!!!
    }
    if (mario.drop) {// && !mario.onBlock) {
        console.log("nonono111111111")
        if (!mario.jump && !mario.jumping) {
            console.log("nonono222222")
            mario.moveDown()
            mario.standY = 600;
            if (mario.y >= mario.standY) {
                mario.topY = mario.jumpHeight
                mario.drop = false;
            }
        }
        else if(mario.jumping){
            mario.drop = false;
            console.log("nonono")
        }
    }
    if (mario.jump && !mario.drop) {
        mario.moveJump()
        if (mario.y <= mario.topY) {
            if (mario.onBlock) {
                mario.topY = block.y - mario.jumpHeight - mario.h//duplicate????
            }
            else {
                mario.topY = mario.jumpHeight;
            }
            mario.jump = false;
            mario.jumped = true;
            mario.jspeed = -mario.j;
        }
        /*else if (mario.drop && !mario.onBlock) {
            if (mario.y <= 600) {
                mario.topY = mario.jumpHeight;
            }
            mario.jump = false;
            mario.jumped = true;
            mario.jspeed = -mario.j;
        }*/
    }
    //ready to jump down after reach the jump height
    else if (mario.jumped) {
        mario.moveJump()
        console.log("yes")
        if (mario.onBlock) {
            mario.standY = block.y - mario.h
        }
        else {
            mario.standY = 600;
        }
        if (mario.y >= mario.standY) {
            mario.y = mario.standY
            mario.jspeed = mario.j;
            mario.jumped = false;
            mario.jumping = false;
        }
    }
    console.log(mario.drop, mario.onBlock, mario.jump, mario.jumped, mario.jumping, mario.y, mario.topY, mario.standY)
    //update each bullet movement
    for (let i = 0; i < bullets.length; i++) {
        if (bullets[i].fire) {
            bullets[i].move()
            if (bullets[i].distance >= 350) {
                bullets[i].gone()
            }
        }
    }
    //check for collide with monsters
    for (let i = 0; i < monsters.length; i++) {
        if (!monsters[i].kill) {//save memory maybe
            monsters[i].move()
            if (mario.collideWithMonster(monsters[i])) {
                monsters[i].killed()
            }
            for (let j = 0; j < bullets.length; j++) {
                if (bullets[j].fire && bullets[j].collide(monsters[i])) {
                    monsters[i].killed()
                    bullets[j].gone()
                }
            }
        }
    }
    //invulnerable buff
    if (mario.invulnerable) {
        mario.invulnerableTime++;
        marioColor = mario.colorInv;
        if (mario.invulnerableTime >= fps * 1) {//1 sec invulnerable buff
            mario.invulnerable = false;
            marioColor = mario.color;
            mario.invulnerableTime = 0;
        }
    }
};