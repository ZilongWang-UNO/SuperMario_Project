function update() {
    if (mario.jump) {
        mario.moveJump()
        if (mario.y <= 400) {
            mario.jump = false;
            mario.jumped = true;
            mario.jspeed = -mario.j;
        }
    }
    else if (mario.jumped) {
        mario.moveJump()
        if (mario.y >= 600) {
            mario.jspeed = mario.j;
            mario.jumped = false;
            mario.jumping = false;
        }
    }
    for (let i = 0; i < monsters.length; i++) {
        if (!monsters[i].kill) {//save memory maybe
            monsters[i].move()
            if (mario.collide(monsters[i])) {
                monsters[i].killed()
            }
        }
    }
    if (mario.invulnerable) {
        mario.invulnerableTime++;
        marioColor = mario.colorInv;
        if (mario.invulnerableTime >= fps * 3) {//3 sec invulnerable buff
            mario.invulnerable = false;
            marioColor = mario.color;
            mario.invulnerableTime = 0;
        }
    }
};