function update() {
    if (!instruction) {
        timeCount++
        if (timeCount == 32) {
            timeCount = 0
            time--
            if (time == 0) {
                gameOver = true
            }
        }
    }

    //MarioUpdate.update()
    //BulletUpdate.update()
    //MapUpdate.update()

};