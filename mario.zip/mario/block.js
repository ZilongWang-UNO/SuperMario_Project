function Block() {
    let o = {
        x: 500,
        y: 450,//480
        w: 200,
        h: 100,
        speed: 10,
    };
    o.moveLeft = function () {
        o.x -= o.speed;
    }
    return o;
}