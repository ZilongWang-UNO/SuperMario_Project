class GameObject{
  constructor(){
    this.components = [];
  }
  static update(){
    this.components.filter(c=>c.update).forEach(c=>c.update());
  }
  static draw(){
    this.components.filter(c=>c.draw).forEach(c=>c.draw());
  }
}

//export default GameObject;