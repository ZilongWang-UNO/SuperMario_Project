class MapDraw extends Component {
    constructor(parent) {
        super(parent);
    }
    static draw(ctx) {

        let offsetIndex = Math.abs(parseInt(offsetX / map.tileSize)) * map.th
        enemies = enemies.filter(a => a.position >= offsetIndex)
        let numberOfTiles = map.th * (21)
        let maxIndex = offsetIndex + numberOfTiles
        if (maxIndex > tiles.length) {
            offsetIndex = 0
        }
        for (let i = offsetIndex; i < maxIndex; i++) {
            let index = tiles[i]
            if (index != 0) {
                let x = Math.floor(i / map.th) * map.tileSize + offsetX
                let y = (i % map.th) * map.tileSize
                if (index == 1 && sceneType == 2)
                    ctx.fillStyle = "#008088"
                else
                    ctx.fillStyle = map.colors[index - 1]

                //enemy move
                if (index == 5) {
                    if (!enemies.some(a => a.position == i)) {
                        enemies.push({ "number": enemyCount, "position": i, "speed": 0, "direction": 2, "dropSpeed": 0, "vy": 0, "y": y })
                        enemyCount++
                    }
                    for (let key in enemies) {
                        if (enemies[key].position == i) {
                            x += enemies[key].speed
                            y = enemies[key].y
                        }
                    }
                    if (x > 0) {
                        ctx.fillRect(x, y, map.tileSize, map.tileSize);
                    }
                    else {
                        //if not draw, delete from map and enemies array
                        tiles[i] = 0
                        enemies = enemies.filter(a => a.position != i)
                    }
                }
                else
                    ctx.fillRect(x, y, map.tileSize, map.tileSize)
            }
        }

    }
}