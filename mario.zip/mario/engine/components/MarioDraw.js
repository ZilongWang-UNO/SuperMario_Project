class MarioDraw extends Component {
    constructor(parent) {
        super(parent);
    }
    static draw(ctx) {

        if (!mario.fire && !mario.invulnerable)
            ctx.fillStyle = "pink";
        else
            ctx.fillStyle = marioColor;
        ctx.fillRect(mario.x, mario.y, mario.w, mario.h);
    }
}

export default MarioDraw;