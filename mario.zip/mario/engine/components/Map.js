class Map extends Component {
    constructor(parent) {
        super(parent);
        this.th = 16;
        this.vx = 0;
        this.mx = 0;
        this.speed = 0.5;
        this.tileSize = 32;
        this.colors = [
            "#C84C0C",   // block       1  // #008088 for scene 2
            "#FC9838",   // items       2
            "#FFFFFF",   // cloud       3
            "#80D010",   // tube        4
            "#fcd8a8",   // enemy       5
            "purple",    // mushroom    6
            "#fc9838",   // coin        7  
        ];
    }

    onGround(i, j, which) {
        
        //
        let p = 0
        let y = 0
        let currentSpeed = 0
        let currentYSpeed = 0
        let index = i * this.th + j
        let tile = tiles[index]
        let index1 = 0

        //go underground
        if ((index == 922 || index == 938) && down && sceneType == 1) {
            this.changeScene()
            return
        }

        //eat coins
        if (tile == 7) {
            mario.score += 200
            coin++
            tiles[index] = 0
        }

        if (enemies.length > 0) {
            for (let key in enemies) {
                currentSpeed = enemies[key].speed
                currentYSpeed = enemies[key].dropSpeed
                y = enemies[key].y
                p = enemies[key].position
                index1 = (i - Math.round(currentSpeed / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)

                if (index1 == p && !mario.jumping && which == "mario") {
                    mario.score += 100
                    tiles[index1] = 0
                    enemies = enemies.filter(a => a.position != index1)
                    break
                }
            }
        }
        return tile == 1 || tile == 2 || tile == 4
    }

    touchBlock(i, j, which) {
        let p = 0
        let currentSpeed = 0
        let currentYSpeed = 0
        let index = i * this.th + j
        let tile = tiles[index]
        let hit = false

        //exit from underground
        if (sceneType == 2 && (index == 222 - mario.h / map.tileSize)) {
            exitFromUnderground = true
            return
        }

        //eat mushroom
        if (tile == 6 && which == "mario") {
            if (!mario.big) {
                mario.changeSize()
            }
            else {
                mario.fire = true
            }
            mario.score += 1000
            tiles[index] = 0
        }

        //eat coins
        if (tile == 7 && which == "mario") {
            mario.score += 200
            coin++
            tiles[index] = 0
        }

        if (which == "mario" || which == "bullet") {
            let index1 = 0
            if (enemies.length > 0) {
                for (let key in enemies) {
                    currentSpeed = enemies[key].speed
                    currentYSpeed = enemies[key].dropSpeed
                    p = enemies[key].position
                    if ((mario.faceLeft && enemies[key].direction < 0) || (mario.faceRight && enemies[key].direction > 0))
                        index1 = (i - Math.round(currentSpeed / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)
                    else if (mario.faceRight && enemies[key].direction < 0) {
                        index1 = (i - Math.round((currentSpeed + mario.w) / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)
                    }
                    else
                        index1 = (i - Math.round((currentSpeed - mario.w) / map.tileSize)) * this.th + j - Math.round(currentYSpeed / map.tileSize)

                    //touch enemies, update mario's lives and give buff or reduce body height
                    if (index1 == p) {
                        if (which == "mario") {
                            if (mario.big) {
                                mario.changeSize()
                                mario.fire = false
                                mario.invulnerable = true
                            }
                            else if (!mario.invulnerable) {
                                hp--
                                if (hp > 0) {
                                    init()
                                }
                                else {
                                    gameOver = true
                                }
                            }
                        }
                        else {
                            mario.score += 100
                            hit = true
                            tiles[index1] = 0
                            enemies = enemies.filter(a => a.position != index1)
                        }
                        break
                    }
                }
            }
        }

        //win 
        if (which == "mario" && index >= 3237 && index <= 3245 - mario.h / 32)
            win = true
        return tile == 1 || tile == 2 || tile == 4 || hit
    }

    headTouch(i, j) {
        let index = i * this.th + j
        let tile = tiles[index]

        //eat coins
        if (tile == 7) {
            mario.score += 200
            coin++
            tiles[index] = 0
        }

        return tile == 1 || tile == 2
    }

    changeScene() {
        if (sceneType == 1) {
            sceneType = 2
            sceneColor = 'black'
            offsetX = 0
            mario.x = 64
            mario.y = 32
            mario.vx = 0
            tiles = tileList2.slice(0)
        }
        else if (sceneType == 2) {
            sceneType = 1
            sceneColor = '#5C94FC'
            offsetX = -5056
            mario.x = 320
            mario.y -= 65
            tiles = tileList.slice(0)
        }
    }
}