class BulletUpdate extends Component {
    constructor(parent) {
        super(parent);
    }
    static update() {

        if (!win && !exitFromUnderground) {
            for (let i = 0; i < bullets.length; i++) {
                bullets[i].move()

                //check hit with enemies
                let bi = 0
                if (bullets[i].left)
                    bi = Math.floor((bullets[i].x - bullets[i].w) / map.tileSize + offset)
                else
                    bi = Math.ceil((bullets[i].x + bullets[i].w) / map.tileSize + offset)
                let bj = Math.floor(bullets[i].y / map.tileSize)
                touchBlock = map.touchBlock(bi, bj, "bullet")
                if (touchBlock) {
                    bullets[i].gone()
                }
                else if (bullets[i].distance >= 350) {
                    bullets[i].gone()
                }
            }
            bullets = bullets.filter(b => b.fire == true)
        }
    }
}