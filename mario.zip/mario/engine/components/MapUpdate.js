class MapUpdate extends Component {
    constructor(parent) {
        super(parent);
    }
    static update() {
        let i;
        let j;

        if (!win && !exitFromUnderground) {
            //enemies check
            if (enemies.length > 0) {
                for (let key in enemies) {
                    enemies[key].speed -= enemies[key].direction
                    let pos = enemies[key].position
                    let tempSpeed = enemies[key].speed
                    let x = Math.floor(pos / map.th) * map.tileSize + offsetX
                    let y = enemies[key].y
                    i = Math.round((x + tempSpeed) / map.tileSize + offset)
                    j = Math.floor(y / map.tileSize) + 1
                    if (map.onGround(i + 1, j, "enemy")) {
                        i = Math.ceil((x + tempSpeed) / map.tileSize + offset)
                    }
                    else if (map.onGround(i - 1, j, "enemy")) {
                        i = Math.floor((x + tempSpeed) / map.tileSize + offset)
                    }

                    //on ground
                    onGround = map.onGround(i, j, "enemy")
                    if (!onGround) {
                        enemies[key].y += enemies[key].vy
                        enemies[key].dropSpeed += enemies[key].vy
                        enemies[key].vy += mario.gy * 0.1
                        if (enemies[key].y > 470) {
                            let pos = enemies[key].position
                            tiles[pos] = 0
                            enemies = enemies.filter(a => a.position != pos)
                            break
                        }
                    }
                    else {
                        enemies[key].y = (j - 1) * map.tileSize
                        let y1 = (pos % map.th) * map.tileSize
                        if (enemies[key].dropSpeed != 0)
                            enemies[key].dropSpeed = enemies[key].y - y1
                        enemies[key].vy = 0
                    }

                    //touch block
                    if (enemies[key].direction > 0)
                        i = Math.floor((x + tempSpeed) / map.tileSize + offset)
                    else
                        i = Math.ceil((x + tempSpeed) / map.tileSize + offset)
                    touchBlock = map.touchBlock(i, j - 1, "enemy")
                    if (touchBlock) {
                        enemies[key].direction *= -1
                    }
                }
            }
        }
    }
}