class BulletDraw extends Component {
    constructor(parent) {
        super(parent);
    }
    static draw(ctx) {

        for (let i = 0; i < bullets.length; i++) {
            ctx.fillStyle = "orange";
            if (bullets[i].right)
                ctx.fillRect(bullets[i].x + mario.w, bullets[i].y, bullets[i].w, bullets[i].h);
            else
                ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].w, bullets[i].h);
        }

    }
}

export default BulletDraw;