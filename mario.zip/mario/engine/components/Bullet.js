class Bullet extends Component {
    constructor(parent) {
        super(parent);
        this.x = mario.x
        this.y = mario.y + mario.h / 2
        this.w = 10
        this.h = 10
        this.speed = 15
        this.fire = false
        this.distance = 0
        this.left = mario.faceLeft
        this.right = mario.faceRight
    }

    move() {
        if (this.left) {
            this.x -= this.speed;
        }
        else if (this.right)
        this.x += this.speed;
        this.distance += this.speed;
    };

    fired() {
        this.fire = true;
    };

    gone() {
        this.fire = false;
    }

}